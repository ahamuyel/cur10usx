"use client"

import Link from "next/link"
import { useTranslation } from "@/lib/i18n"
import { GraduationCap } from "lucide-react"
import LocaleSwitcher from "./LocaleSwitcher"

type Props = {
  locale?: string
}

const socialLinks = [
  {
    label: "Facebook",
    href: "#",
    hoverColor: "hover:text-[#1877F2]",
  },
  {
    label: "Instagram",
    href: "#",
    hoverColor: "hover:text-[#E4405F]",
  },
  {
    label: "LinkedIn",
    href: "#",
    hoverColor: "hover:text-[#0A66C2]",
  },
]

export default function Footer({ locale = "pt" }: Props) {
  const { t } = useTranslation(locale)
  const year = new Date().getFullYear()

  return (
    <footer className="bg-[var(--landing-bg-secondary)] border-t border-[var(--landing-border)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main footer grid */}
        <div className="py-16 md:py-20 grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-12">
          {/* Brand column */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-neutral-900 dark:bg-white text-white dark:text-zinc-900">
                <GraduationCap className="w-4 h-4" />
              </div>
              <span className="font-bold text-sm text-[var(--landing-text-primary)]">
                Cur10usX
              </span>
            </div>
            <p className="text-xs text-[var(--landing-text-dim)] leading-relaxed max-w-xs mb-6">
              {t("landing.footer.description")}
            </p>
            <div className="flex items-center gap-2">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`p-2 rounded-lg text-[var(--landing-text-dim)] ${social.hoverColor} hover:bg-[var(--landing-bg-tertiary)] transition`}
                  aria-label={social.label}
                >
                  {social.label === "Facebook" && (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                  )}
                  {social.label === "Instagram" && (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                    </svg>
                  )}
                  {social.label === "LinkedIn" && (
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                    </svg>
                  )}
                </a>
              ))}
            </div>
          </div>

          {/* Product */}
          <div className="space-y-4">
            <span className="text-[10px] text-[var(--landing-text-dim)] uppercase tracking-widest font-semibold">
              {t("landing.footer.product")}
            </span>
            <ul className="space-y-3">
              <li>
                <a href="#ecosystem" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.ecosystem.modules.0.title")}
                </a>
              </li>
              <li>
                <a href="#ecosystem" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.ecosystem.modules.1.title")}
                </a>
              </li>
              <li>
                <a href="#ecosystem" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.ecosystem.modules.2.title")}
                </a>
              </li>
              <li>
                <a href="#ecosystem" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.ecosystem.modules.3.title")}
                </a>
              </li>
              <li>
                <a href="#ecosystem" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.ecosystem.modules.6.title")}
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="space-y-4">
            <span className="text-[10px] text-[var(--landing-text-dim)] uppercase tracking-widest font-semibold">
              {t("landing.footer.resources")}
            </span>
            <ul className="space-y-3">
              <li>
                <a href="#transformation" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.transformation.tag")}
                </a>
              </li>
              <li>
                <a href="#benefits" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.benefits.tag")}
                </a>
              </li>
              <li>
                <a href="#vision" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.vision.tag")}
                </a>
              </li>
              <li>
                <a href="#trust" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  {t("landing.trust.tag")}
                </a>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <span className="text-[10px] text-[var(--landing-text-dim)] uppercase tracking-widest font-semibold">
              {t("landing.footer.company")}
            </span>
            <ul className="space-y-3">
              <li>
                <Link href="/termos" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  Termos de Serviço
                </Link>
              </li>
              <li>
                <Link href="/privacidade" className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors">
                  Política de Privacidade
                </Link>
              </li>
              <li className="pt-2">
                <p className="text-xs text-[var(--landing-text-dim)]">{t("landing.footer.contact")}</p>
                <a
                  href="mailto:suporte@cur10usx.com"
                  className="text-xs text-[var(--landing-text-muted)] hover:text-[var(--landing-text-primary)] transition-colors"
                >
                  suporte@cur10usx.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[var(--landing-border)] py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-2 text-xs text-[var(--landing-text-dim)]">
            <span>&copy; {year} {t("landing.footer.copyright")}</span>
            <span className="hidden sm:inline text-[var(--landing-border)]">|</span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              {t("landing.footer.status")}
            </span>
          </div>
          {/* <div className="flex items-center gap-4 text-[11px] text-[var(--landing-text-dim)]">
            <LocaleSwitcher currentLocale={locale} />
          </div> */}
        </div>
      </div>
    </footer>
  )
}
